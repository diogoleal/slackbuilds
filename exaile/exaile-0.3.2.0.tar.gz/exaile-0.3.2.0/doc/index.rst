Welcome to Exaile's documentation!
==================================

Contents:

.. toctree::

    xl/trax
    xl/cover
    xl/metadata


Indices and tables
==================

* :ref:`modindex`
* :ref:`search`

